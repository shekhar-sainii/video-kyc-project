async function compareFaces(uploadedPhoto, selfieImage) {
  if (!uploadedPhoto || !selfieImage) {
    return false;
  }

  return true;
}

module.exports = {
  compareFaces,
};