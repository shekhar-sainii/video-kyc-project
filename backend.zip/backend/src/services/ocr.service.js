const Tesseract = require("tesseract.js");

async function extractPanNumber(imagePath) {
  const result = await Tesseract.recognize(
    imagePath,
    "eng"
  );

  const text = result.data.text;

  const panMatch = text.match(
    /[A-Z]{5}[0-9]{4}[A-Z]{1}/
  );

  return panMatch ? panMatch[0] : null;
}

module.exports = {
  extractPanNumber,
};