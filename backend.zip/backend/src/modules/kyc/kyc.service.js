const kycRepository = require("./kyc.repository");

class KYCService {
  async submitKyc(data) {
    const existingApplication = await kycRepository.findByPanNumber(data.panNumber);

    if (existingApplication) {
      throw new Error("KYC application already exists for this PAN number");
    }

    return await kycRepository.create({
      panNumber: data.panNumber,
      signature: data.signature,
      uploadedPhoto: data.uploadedPhoto,
    });
  }

  async getApplications() {
    return await kycRepository.getAllApplications();
  }

  async verifyKyc(applicationId, verificationData) {
    const application = await kycRepository.findById(applicationId);

    if (!application) {
      throw new Error("Application not found");
    }

    const extractedPan = verificationData.extractedPan;
    const faceMatch = verificationData.faceMatch;

    const panMatch =
      extractedPan &&
      extractedPan.toUpperCase() === application.panNumber.toUpperCase();

    let status = "Rejected";
    let verificationMessage = "";

    if (faceMatch && panMatch) {
      status = "Verified";
      verificationMessage = "KYC Verified Successfully";
    } else if (!faceMatch && !panMatch) {
      verificationMessage = "Face mismatch and PAN mismatch";
    } else if (!faceMatch) {
      verificationMessage = "Face mismatch";
    } else {
      verificationMessage = "PAN mismatch";
    }

    return await kycRepository.updateVerification(applicationId, {
      panCardImage: verificationData.panCardImage,
      selfieImage: verificationData.selfieImage,
      faceMatch,
      panMatch,
      status,
      verificationMessage,
    });
  }
}

module.exports = new KYCService();
