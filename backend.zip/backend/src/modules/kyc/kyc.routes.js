const express = require("express");
const router = express.Router();

const upload = require("../../config/multer");
const kycController = require("./kyc.controller");

router.post(
  "/submit",
  upload.single("uploadedPhoto"),
  kycController.submitKyc
);

router.get(
  "/applications",
  kycController.getApplications
);

router.post(
  "/verify",
  upload.fields([
    { name: "panCardImage", maxCount: 1 },
    { name: "selfieImage", maxCount: 1 },
  ]),
  kycController.verifyKyc
);

module.exports = router;