/**
 * @swagger
 * tags:
 *   name: Payment
 *   description: Payment management APIs (User & Admin)
 */

/**
 * @swagger
 * /payment:
 *   post:
 *     summary: Initiate payment for an order
 *     tags: [Payment]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - orderId
 *               - provider
 *             properties:
 *               orderId:
 *                 type: string
 *                 example: 64f123abc4567890
 *               provider:
 *                 type: string
 *                 enum:
 *                   - stripe
 *                   - razorpay
 *                   - paypal
 *                   - cod
 *                 example: stripe
 *               idempotencyKey:
 *                 type: string
 *                 example: unique-key-123
 *     responses:
 *       201:
 *         description: Payment initiated successfully
 *       400:
 *         description: Invalid request
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /payment:
 *   get:
 *     summary: Get logged-in user's payments
 *     tags: [Payment]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Payments fetched successfully
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /payment/admin/all:
 *   get:
 *     summary: Get all payments (Admin only)
 *     tags: [Payment]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: All payments fetched successfully
 *       403:
 *         description: Access denied
 */

/**
 * @swagger
 * /payment/admin/{id}/refund:
 *   patch:
 *     summary: Refund payment (Admin only)
 *     tags: [Payment]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Payment ID
 *     responses:
 *       200:
 *         description: Payment refunded successfully
 *       404:
 *         description: Payment not found
 */

/**
 * @swagger
 * /payment/webhook/stripe:
 *   post:
 *     summary: Stripe webhook endpoint
 *     tags: [Payment]
 *     description: Receives Stripe webhook events (no authentication required).
 *     responses:
 *       200:
 *         description: Webhook received
 */

/**
 * @swagger
 * /payment/webhook/razorpay:
 *   post:
 *     summary: Razorpay webhook endpoint
 *     tags: [Payment]
 *     description: Receives Razorpay webhook events (no authentication required).
 *     responses:
 *       200:
 *         description: Webhook received
 */

/**
 * @swagger
 * /payment/webhook/paypal:
 *   post:
 *     summary: PayPal webhook endpoint
 *     tags: [Payment]
 *     description: Receives PayPal webhook events (no authentication required).
 *     responses:
 *       200:
 *         description: Webhook received
 */