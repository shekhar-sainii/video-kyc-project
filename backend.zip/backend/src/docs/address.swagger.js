/**
 * @swagger
 * tags:
 *   name: Address
 *   description: User Address Management APIs
 */

/**
 * @swagger
 * /address:
 *   post:
 *     summary: Create new address
 *     tags: [Address]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - fullName
 *               - phone
 *               - street
 *               - city
 *               - state
 *               - country
 *               - postalCode
 *             properties:
 *               fullName:
 *                 type: string
 *                 example: Shekhar Saini
 *               phone:
 *                 type: string
 *                 example: 9876543210
 *               street:
 *                 type: string
 *                 example: 221B Baker Street
 *               city:
 *                 type: string
 *                 example: London
 *               state:
 *                 type: string
 *                 example: Greater London
 *               country:
 *                 type: string
 *                 example: UK
 *               postalCode:
 *                 type: string
 *                 example: NW16XE
 *               isDefault:
 *                 type: boolean
 *                 example: true
 *     responses:
 *       201:
 *         description: Address created successfully
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /address:
 *   get:
 *     summary: Get all addresses of logged-in user
 *     tags: [Address]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Addresses fetched successfully
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /address/default:
 *   get:
 *     summary: Get default address
 *     tags: [Address]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Default address fetched successfully
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /address/{id}:
 *   patch:
 *     summary: Update address
 *     tags: [Address]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Address ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               fullName:
 *                 type: string
 *               phone:
 *                 type: string
 *               street:
 *                 type: string
 *               city:
 *                 type: string
 *               state:
 *                 type: string
 *               country:
 *                 type: string
 *               postalCode:
 *                 type: string
 *               isDefault:
 *                 type: boolean
 *     responses:
 *       200:
 *         description: Address updated successfully
 *       404:
 *         description: Address not found
 */

/**
 * @swagger
 * /address/{id}/default:
 *   patch:
 *     summary: Set address as default
 *     tags: [Address]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Address ID
 *     responses:
 *       200:
 *         description: Default address updated successfully
 *       404:
 *         description: Address not found
 */

/**
 * @swagger
 * /address/{id}:
 *   delete:
 *     summary: Delete address
 *     tags: [Address]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Address ID
 *     responses:
 *       200:
 *         description: Address deleted successfully
 *       404:
 *         description: Address not found
 */