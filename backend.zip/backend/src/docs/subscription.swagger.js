require("./auth.swagger");

/**
 * @swagger
 * tags:
 *   name: Subscription
 *   description: Subscription management APIs (User & Admin)
 */

/**
 * @swagger
 * /subscriptions:
 *   post:
 *     summary: Create a new subscription
 *     tags: [Subscription]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - plan
 *               - provider
 *             properties:
 *               plan:
 *                 type: string
 *                 enum:
 *                   - basic
 *                   - pro
 *                   - enterprise
 *                 example: pro
 *               provider:
 *                 type: string
 *                 enum:
 *                   - stripe
 *                   - razorpay
 *                   - paypal
 *                 example: stripe
 *     responses:
 *       201:
 *         description: Subscription created successfully
 *       400:
 *         description: Invalid request
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /subscriptions/me:
 *   get:
 *     summary: Get logged-in user's subscription
 *     tags: [Subscription]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Subscription fetched successfully
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /subscriptions/cancel:
 *   patch:
 *     summary: Cancel active subscription
 *     tags: [Subscription]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Subscription cancelled successfully
 *       400:
 *         description: No active subscription found
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /subscriptions/admin/all:
 *   get:
 *     summary: Get all subscriptions (Admin only)
 *     tags: [Subscription]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Subscriptions fetched successfully
 *       403:
 *         description: Access denied
 */